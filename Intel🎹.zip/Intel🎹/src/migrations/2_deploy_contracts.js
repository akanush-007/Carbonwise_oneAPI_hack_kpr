const CarbonCreditToken = artifacts.require("CarbonCreditToken");

module.exports = function(deployer) {
    deployer.deploy(CarbonCreditToken, 1000000); // Initial supply
};
