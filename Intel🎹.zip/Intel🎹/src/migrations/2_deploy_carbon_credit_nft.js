const CarbonCreditNFT = artifacts.require("CarbonCreditNFT");

module.exports = function (deployer) {
    deployer.deploy(CarbonCreditNFT);
};
