const CarbonCreditManager = artifacts.require("CarbonCreditManager");

contract("CarbonCreditManager", (accounts) => {
    let instance;

    beforeEach(async () => {
        // Create a new instance with an initial supply of 1,000,000 tokens with 18 decimals
        instance = await CarbonCreditManager.new(1000000 * (10 ** 18));

        // Transfer 100 tokens to account[0], again considering decimals
        await instance.transfer(accounts[0], 100 * (10 ** 18)); 
    });

    it("should allow credit retirement", async () => {
        // Ensure the initial balance is 100 for account[0]
        const initialBalance = await instance.balanceOf(accounts[0]);
        assert.equal(initialBalance.toString(), (100 * (10 ** 18)).toString());

        // Retire 100 tokens from account[0]
        await instance.retireCredit(100 * (10 ** 18), { from: accounts[0] });

        // After retirement, balance should be 0
        const balance = await instance.balanceOf(accounts[0]);
        assert.equal(balance.toString(), "0");
    });

    it("should not allow retirement of more credits than owned", async () => {
        try {
            // Attempt to retire 1 credit from account[1], which has no tokens
            await instance.retireCredit(1 * (10 ** 18), { from: accounts[1] });
            assert.fail("The retirement should have thrown an error");
        } catch (error) {
            assert.ok(error.message.includes("Insufficient balance"), "Expected 'Insufficient balance' error");
        }
    });
});
