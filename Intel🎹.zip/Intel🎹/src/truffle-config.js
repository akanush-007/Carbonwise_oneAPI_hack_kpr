const HDWalletProvider = require('@truffle/hdwallet-provider');
const path = require('path');
const fs = require('fs');

const mnemonic = 'convince vanish black attitude play one spatial online camp uphold drastic doctor'; // Replace with your MetaMask seed phrase
const infuraProjectId = '75a14cb22b76492d96c4ec7c96ecd32a';

module.exports = {
    contracts_build_directory: path.join(__dirname, "client/src/contracts"),

    networks: {
        development: {
            host: "127.0.0.1",       // Localhost (default: none)
            port: 7545,              // Standard Ethereum port (default: 7545 for Ganache)
            network_id: "*",         // Any network (default: none)
            gas: 6721975,            // Gas limit
            gasPrice: 20000000000,   // 20 gwei
        },
        sepolia: {
            provider: () => new HDWalletProvider(mnemonic, `https://sepolia.infura.io/v3/${infuraProjectId}`),
            network_id: 11155111,    // Sepolia's id
            gas: 6721975,             // Updated gas limit
            gasPrice: 20000000000,    // 20 gwei
            from: '0x7A9Cf70282a344cb0A9C91b8AC93b147548F7E10',
        },
        local: {
            provider: () => new HDWalletProvider(mnemonic, 'http://0.0.0.0:1337'), // Updated RPC server
            network_id: 5777,         // Local network ID
            gas: 6721975,              // Updated gas limit
            gasPrice: 20000000000,    // 20 gwei
            from: '0x7A9Cf70282a344cb0A9C91b8AC93b147548F7E10',
        }
    },

    compilers: {
        solc: {
            version: "0.8.21",       // Use the compatible version
            settings: {
                optimizer: {
                    enabled: true,
                    runs: 200
                },
            }
        }
    },

    settings: {
        optimizer: {
            enabled: true,
            runs: 200,
        },
        evmVersion: "merge" // Specify hardfork
    }
};
