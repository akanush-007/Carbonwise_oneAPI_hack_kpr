const CarbonCreditManager = artifacts.require("CarbonCreditManager");

module.exports = function(deployer) {
    deployer.deploy(CarbonCreditManager, 1000000); // Initial supply
};
